def lambda_handler(event, context):
    print("Event Received:")
    print(event)
